Forward Foundation - static rebrand
===================================

A rebrand of the chatgpt.com/overview design shell, filled with the actual
content from forwardfnd.org (California nonprofit; free human-confirmed
decision support for family dementia caregivers and the direct-care
workforce). CSS, layout, and interactions stay the same. Text, meta,
titles, and nav are rewritten to Forward Foundation.

How to view
-----------
  ./serve.sh
  # then open http://127.0.0.1:8765

  # or
  python3 -m http.server 8765 --bind 127.0.0.1
  # or
  npx --yes http-server -p 8765 .

Opening index.html via file:// works too but ES modules and web fonts
will not load - use serve.sh for full fidelity.

Content source: https://forwardfnd.org (fetched 2026-07-22).
Design source: https://chatgpt.com/overview/ (Wayback snapshot 2026-07-15).