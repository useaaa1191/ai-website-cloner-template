#!/usr/bin/env bash
# Serve the offline snapshot on http://127.0.0.1:8765
# ES modules and font @font-face rules require a real origin, so a static
# file:// open only renders partially. Run this script and browse to the URL.
set -e
cd "$(dirname "$0")"
PORT="${PORT:-8765}"
echo "Serving Forward Foundation rebrand at $(pwd) at http://127.0.0.1:${PORT}"
if command -v python3 >/dev/null 2>&1; then
  exec python3 -m http.server "$PORT" --bind 127.0.0.1
elif command -v python >/dev/null 2>&1; then
  exec python -m SimpleHTTPServer "$PORT"
elif command -v npx >/dev/null 2>&1; then
  exec npx --yes http-server -p "$PORT" -a 127.0.0.1 .
else
  echo "Need python3 or npx to serve. Install one of them." >&2
  exit 1
fi
