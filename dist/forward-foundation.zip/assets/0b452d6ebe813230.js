var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{AQt as t,FQt as n,LQt as r,WQt as i,kQt as a,qQt as o}from"./4813494d-n80qxxy3ebindl2e.js";function s(){return i()&&!r()&&!n()?u:o()?d:l}function c(){return r()||n()?f:t()?p:l}var l,u,d,f,p,m=e((()=>{a(),l=`/download`,u=`https://persistent.oaistatic.com/sidekick/public/ChatGPT_Desktop_public_latest.dmg`,d=`https://apps.microsoft.com/detail/9nt1r1c2hh7j`,f=`https://apps.apple.com/app/chatgpt/id6448311069`,p=`https://play.google.com/store/apps/details?id=com.openai.chatgpt`}));export{d as a,m as c,p as i,l as n,s as o,u as r,c as s,f as t};
//# sourceMappingURL=bb17ce6f-hpvi8ua8xqtc1trw.js.map
/*
     FILE ARCHIVED ON 11:54:27 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:20 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.51
  captures_list: 1.438
  exclusion.robots: 0.917
  exclusion.robots.policy: 0.054
  esindex: 0.01
  cdx.remote: 13.278
  LoadShardBlock: 211.527 (3)
  PetaboxLoader3.datanode: 294.199 (5)
  load_resource: 231.013 (2)
  PetaboxLoader3.resolve: 74.056
*/