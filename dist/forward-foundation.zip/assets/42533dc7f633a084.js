var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{aZt as t,oZt as n}from"./4813494d-n80qxxy3ebindl2e.js";function r(e){let t=e.trim();if(!t)return`/`;let n=t.replace(/^\/+|\/+$/g,``);return n?`/${n}`:`/`}var i=e((()=>{}));function a(e){return e.startsWith(`/`)&&e.charAt(1)!==`/`}function o(e){try{return new URL(e,m)}catch{return null}}function s(e){return h.has(e)}function c(e,t){return a(e)||s(t.hostname)}function l(e){return e?n(e)==null?x.test(e):!0:!1}function u(e){let t=e.split(`/`),n=t.findIndex(Boolean),r=t[n];n>=0&&r&&l(r)&&t.splice(n,1);let i=t.join(`/`)||`/`;return i.startsWith(`/`)?i:`/${i}`}function d(e){return r(u(e))}function f(e){let t=o(e);return!t||!c(e,t)?null:d(t.pathname)}function p(e){let t=o(e);if(!t||!c(e,t))return null;if(t.searchParams.get(`q`))return g.CHATGPT_QUERY;let n=d(t.pathname);return y[n]||b[t.hash]||(n===`/`&&t.hash===``?g.CHATGPT_FREE_ENTRY:g.CHATGPT_OTHER)}var m,h,g,_,v,y,b,x,S=e((()=>{i(),t(),m=`https://chatgpt.com`,h=new Set([`chatgpt.com`,`www.chatgpt.com`]),g={CHATGPT_CONTACT_SALES:`chatgpt_contact_sales`,CHATGPT_TEAM_ENTRY:`chatgpt_team_entry`,CHATGPT_CONSUMER_PAID_ENTRY:`chatgpt_consumer_paid_entry`,CHATGPT_FREE_ENTRY:`chatgpt_free_entry`,CHATGPT_QUERY:`chatgpt_query`,CHATGPT_OTHER:`chatgpt_other`},_={CONTACT_SALES:`/contact-sales`,TEAM_ENTRY:`/team-sign-up`,EXPLORE_PLUS:`/explore/plus`,EXPLORE_PRO:`/explore/pro`,EXPLORE_GO:`/explore/go`},v={PRICING:`#pricing`},y={[_.CONTACT_SALES]:g.CHATGPT_CONTACT_SALES,[_.TEAM_ENTRY]:g.CHATGPT_TEAM_ENTRY,[_.EXPLORE_PLUS]:g.CHATGPT_CONSUMER_PAID_ENTRY,[_.EXPLORE_PRO]:g.CHATGPT_CONSUMER_PAID_ENTRY,[_.EXPLORE_GO]:g.CHATGPT_CONSUMER_PAID_ENTRY},b={[v.PRICING]:g.CHATGPT_CONSUMER_PAID_ENTRY},x=/^[a-z]{2}(-[A-Za-z0-9]{2,4})?$/}));export{p as a,S as i,d as n,f as r,g as t};
//# sourceMappingURL=282bcbc3-hgfou7warg604xl5.js.map
/*
     FILE ARCHIVED ON 11:54:27 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:20 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.661
  captures_list: 0.535
  exclusion.robots: 0.054
  exclusion.robots.policy: 0.042
  esindex: 0.01
  cdx.remote: 62.406
  LoadShardBlock: 44.113 (3)
  PetaboxLoader3.datanode: 95.55 (4)
  load_resource: 72.537
*/