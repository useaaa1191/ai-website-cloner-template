var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e,r as t}from"./f025431a-nohxu7rfv8lngty8.js";import{Szt as n,cJ as r,cm as i,lm as a,sJ as o,xzt as s}from"./4813494d-n80qxxy3ebindl2e.js";import{Ut as c,xt as l}from"./2340486e-i94pm3kv3z1ngaiv.js";import{n as u,t as d}from"./2686af9f-kf15scxwjzyomh7d.js";import{n as f,t as p}from"./8a4ddaf7-ddcsw4ukvlrsvqyo.js";var m=t({default:()=>b});function h(e){return e.replaceAll(/\s+/g,`-`).toLowerCase()}function g(e){return`caro-${h(e.substring(0,40))}`}function _(e){return`/?prompt=${encodeURI(e).split(`%20`).join(`+`)}`}var v,y,b,x=e((()=>{v=l(),a(),f(),r(),u(),n(),y=c(),b=e=>{"use forget";let t=(0,v.c)(15),{direction:n,items:r,carouselSpeed:a,overrideOnItemClick:c,showSuffixArrow:l,itemWidth:u,contentfulDebugAttributes:f}=e,m=n===void 0?`Left`:n,h=a===void 0?36:a,b=l===void 0?!1:l,x=u===void 0?`default`:u,S=_,C=x===`wide`?`w-[294px]`:`w-[286px]`,w;t[0]===C?w=t[1]:(w=s(C,`rounded-md bg-[var(--bg-secondary)] p-4 text-mkt-p2`),t[0]=C,t[1]=w);let T;if(t[2]!==r||t[3]!==c||t[4]!==b){let e;t[6]!==c||t[7]!==b?(e=(e,t)=>(0,y.jsxs)(i,{href:S(e.inputText??``),className:`w-full break-words hover:underline`,onClick:()=>{if(c){c(e);return}d.logClick({analytics_identifier:g(e.inputText??``)})},underline:!1,children:[e.inputText,b&&(0,y.jsx)(`span`,{className:`relative top-[3px] ms-1 inline-flex items-center`,"aria-hidden":`true`,children:(0,y.jsx)(o,{className:`icon-sm`})})]},t),t[6]=c,t[7]=b,t[8]=e):e=t[8],T=r.map(e),t[2]=r,t[3]=c,t[4]=b,t[5]=T}else T=t[5];let E;return t[9]!==h||t[10]!==f||t[11]!==m||t[12]!==w||t[13]!==T?(E=(0,y.jsx)(p,{contentfulDebugAttributes:f,direction:m,carouselSpeed:h,itemWrapperClassName:w,items:T,threshold:.66}),t[9]=h,t[10]=f,t[11]=m,t[12]=w,t[13]=T,t[14]=E):E=t[14],E}}));export{m as n,x as r,b as t};
//# sourceMappingURL=9e9d908a-mplijaffiym8ibfq.js.map
/*
     FILE ARCHIVED ON 11:54:27 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:20 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.318
  captures_list: 0.441
  exclusion.robots: 0.046
  exclusion.robots.policy: 0.038
  esindex: 0.008
  cdx.remote: 13.777
  LoadShardBlock: 91.533 (3)
  PetaboxLoader3.datanode: 190.888 (5)
  load_resource: 231.969 (2)
  PetaboxLoader3.resolve: 83.79 (2)
*/