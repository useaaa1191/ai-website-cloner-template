var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{Azt as t,GTt as n,JTt as r,Ozt as i,nQt as a,rQt as o}from"./4813494d-n80qxxy3ebindl2e.js";import{a as s,i as c}from"./282bcbc3-hgfou7warg604xl5.js";function l(){return!1}function u(){return o(`${window.location.pathname}${window.location.search}${window.location.hash}`)}function d(e,t){l()&&console.log(`[ContentfulLogger]`,e,t??{})}var f,p=e((()=>{t(),c(),a(),n(),f={logPageView(e={}){i.logEventWithStatsig(`Contentful: Page Viewed`,`chatgpt_web_contentful_page_viewed`,{slug:e.slug}),d(`Contentful: Page Viewed`,{slug:e.slug})},logClick(e={}){let t=e.destination_url,n=t?s(t):null;i.logEventWithStatsig(`Contentful: Link Button Clicked`,`chatgpt_web_contentful_link_button_clicked`,{analytics_identifier:e.analytics_identifier,destination_url:t,...n&&{intent:n},...e.path&&{path:r(e.path)}}),d(`Contentful: Link Button Clicked`,{analytics_identifier:e.analytics_identifier,intent:n})},logNavigation(e={}){let t=e.from??u();i.logEventWithStatsig(`Contentful: Navigation Clicked`,`chatgpt_web_contentful_navigation_clicked`,{analytics_identifier:e.analytics_identifier,from:t,navigation_surface:e.navigation_surface,to:e.to}),d(`Contentful: Navigation Clicked`,{analytics_identifier:e.analytics_identifier,from:t,navigation_surface:e.navigation_surface,to:e.to})},logLocaleChanged(e){i.logEventWithStatsig(`Contentful: Locale Changed`,`chatgpt_web_contentful_locale_changed`,{locale:e.locale}),d(`Contentful: Locale Changed`,{locale:e.locale})}}}));export{p as n,f as t};
//# sourceMappingURL=2686af9f-kf15scxwjzyomh7d.js.map
/*
     FILE ARCHIVED ON 11:54:27 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:20 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 11.552
  captures_list: 0.543
  exclusion.robots: 0.053
  exclusion.robots.policy: 0.042
  esindex: 0.01
  cdx.remote: 43.158
  LoadShardBlock: 171.886 (3)
  PetaboxLoader3.datanode: 204.598 (4)
  load_resource: 188.441
  PetaboxLoader3.resolve: 133.168
*/