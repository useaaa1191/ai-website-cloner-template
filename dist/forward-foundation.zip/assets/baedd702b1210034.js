var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{i as t,n}from"./1fbff149-dqoc48v9re2ppjo6.js";var r=e((()=>{t(),n()}));export{r as t};
//# sourceMappingURL=c3e2d78f-f4eo7fjq2cfgi58p.js.map
/*
     FILE ARCHIVED ON 11:54:27 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:20 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.418
  captures_list: 0.5
  exclusion.robots: 0.052
  exclusion.robots.policy: 0.042
  esindex: 0.011
  cdx.remote: 7.952
  LoadShardBlock: 100.728 (3)
  PetaboxLoader3.datanode: 62.579 (4)
  PetaboxLoader3.resolve: 69.944 (2)
  load_resource: 86.78
*/