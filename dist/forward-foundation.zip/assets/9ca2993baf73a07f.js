var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/conversation-small-nj3jro5w24kaci4p.js","assets/2340486e-i94pm3kv3z1ngaiv.js","assets/f025431a-nohxu7rfv8lngty8.js","assets/4813494d-n80qxxy3ebindl2e.js","assets/root-od14me7o.css","assets/30901919-lsuznljs1enztexh.js","assets/c470f5ab-gsimuo2pnew8v51o.js","assets/0e5afe53-m5elbchq1kx5xrqe.js","assets/conversation-small-dyf078sa.css"])))=>i.map(i=>d[i]);
import{n as e,s as t}from"./f025431a-nohxu7rfv8lngty8.js";import{Czt as n,FZt as r,GXt as i,KXt as a,KZt as o,LZt as s,NXt as c,Tzt as l,i$t as u,jXt as d,n$t as f,qZt as p,r$t as m}from"./4813494d-n80qxxy3ebindl2e.js";import{F as h,I as g,Tt as _,Ut as v,Wt as y,mt as b,wt as x}from"./2340486e-i94pm3kv3z1ngaiv.js";var S,C,w,T=e((()=>{S=[`q`,`m`,`disable_auto_send`],C=e=>S.filter(t=>e.has(t)),w=(e,t)=>{try{let n=new URL(t),r=new URL(e.entryUrl);r.hash=n.hash;let i=new URLSearchParams(n.hash.startsWith(`#`)?n.hash.slice(1):n.hash),a=new Set([...e.instantPromptParameterNames,...C(i)]);return{...e,entryUrl:r.toString(),instantPromptParameterNames:S.filter(e=>a.has(e))}}catch{return e}}}));function E(e){window.jsdOnload=()=>{let t=window.cloudflare?.jsd;if(!t){D(`jsd_unavailable`);return}t.executeOnce({callback:D,nonce:e})};let t=document.createElement(`script`);t.async=!0,t.nonce=e,t.onerror=()=>{D(`script_load_error`)},t.src=A,document.head.appendChild(t)}function D(e){r.addAction(`manual_cloudflare_challenge_invocation`,{outcome:e})}function O(e){let t=window.location.hostname;t!==`chatgpt.com`&&!t.endsWith(`.chatgpt.com`)||d(k).get(`enabled`,!1)&&(j||(j=!0,E(e)))}var k,A,j,M=e((()=>{s(),c(),k=`1171720776`,A=`/cdn-cgi/challenge-platform/scripts/jsd/api.js?onload=jsdOnload`,j=!1}));function N(e){let t=e=>e.filter(e=>/\.css([?#]|$)/.test(e)),n=Object.fromEntries(Object.entries(e.routes).map(([e,n])=>[e,n?.imports?{...n,imports:t(n.imports)}:n])),r=e.entry?.imports?{...e.entry,imports:t(e.entry.imports)}:e.entry;return{...e,entry:r,routes:n}}var P=e((()=>{})),F,I,L,R,z,B;e((()=>{u(),T(),m(),i(),M(),F=t(y()),I=t(b()),g(),p(),n(),P(),L=v(),_(),window.__oai_SSR_HTML?(f.instance.addFirstTiming(`composer.html`,{time:window.__oai_SSR_HTML,serialTimingGroup:`pageLoad`,source:`inline-script`}),l.setSubmetric(`composerHtmlDurationMs`,window.__oai_SSR_HTML-performance.timeOrigin)):window.__oai_logHTML=()=>{f.instance.addFirstTiming(`composer.html`,{serialTimingGroup:`pageLoad`,source:`entry.client`}),l.setSubmetric(`composerHtmlDurationMs`,performance.now())},window.__oai_SSR_TTI?(f.instance.addFirstTiming(`composer.visible`,{time:window.__oai_SSR_TTI,serialTimingGroup:`pageLoad`,source:`inline-script`}),l.setSubmetric(`composerVisibleDurationMs`,window.__oai_SSR_TTI-performance.timeOrigin)):window.__oai_logTTI=()=>{f.instance.addFirstTiming(`composer.visible`,{serialTimingGroup:`pageLoad`,source:`entry.client`}),l.setSubmetric(`composerVisibleDurationMs`,performance.now())},f.instance.addTiming(`entry.client`,{serialTimingGroup:`pageLoad`}),l.setSubmetric(`entryClientDurationMs`,performance.now()),R=e=>{let t=window.__reactRouterManifest;if(!t||!e.stripModulepreloadImports)return;let n=N(t);window.__reactRouterManifest=n,window.__reactRouterContext?.manifest&&(window.__reactRouterContext={...window.__reactRouterContext,manifest:n})},z=e=>{e.isOpaqueNoAuthDisabledLandingPageEnabled&&Promise.all([x(()=>import(`./conversation-small-nj3jro5w24kaci4p.js`).then(e=>(e.aZ(),e.oZ)),__vite__mapDeps([0,1,2,3,4,5,6,7,8])),x(()=>import(`./4813494d-n80qxxy3ebindl2e.js`).then(e=>(e.KDt(),e.qDt)),__vite__mapDeps([3,1,2,4]))]).then(([{LoginForm:e},{AuthModal:t}])=>{t.prefetch(),e.prefetch()})},B=o(),a(B.integrityStateAuthDelivery,B.session?.accessToken),B.entryContext=w(B.entryContext,window.location.href),O(B.cspScriptNonce),R(B),z(B),(0,F.startTransition)(()=>{(0,I.hydrateRoot)(document,(0,L.jsxs)(F.StrictMode,{children:[null,(0,L.jsx)(h,{})]}),{onRecoverableError(e,t){let n=Error(`${e instanceof Error?e.message:String(e)}`);n.name=`RecoverableError`,n.stack=t.componentStack??(e instanceof Error?e.stack:String(e)),n.cause=e,f.instance.addError(n)}})})}))();
//# sourceMappingURL=entry.client-dy9p1es5.js.map
}

/*
     FILE ARCHIVED ON 17:18:58 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:45 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.767
  load_resource: 1067.949
  PetaboxLoader3.resolve: 1002.289
  PetaboxLoader3.datanode: 63.191
*/