var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";function t(){return typeof window<`u`}function n(){return!t()}var r=e((()=>{}));function i(){return window[s]}function a(e){s=e}function o(e){window[s]=e}var s,c=e((()=>{s=`analytics`})),l,u,d,f,p,m,h,g=e((()=>{c(),l=/(https:\/\/.*)\/analytics\.js\/v1\/(?:.*?)\/(?:platform|analytics.*)?/,u=function(){var e;return Array.prototype.slice.call(document.querySelectorAll(`script`)).forEach(function(t){var n=t.getAttribute(`src`)??``,r=l.exec(n);r&&r[1]&&(e=r[1])}),e},f=function(){return d??i()?._cdn},p=function(e){var t=i();t&&(t._cdn=e),d=e},m=function(){return f()||u()||`https://cdn.segment.com`},h=function(){return`${m()}/next-integrations`}}));function _(e){return Array.prototype.slice.call(window.document.querySelectorAll(`script`)).find(function(t){return t.src===e})}function v(e,t){var n=_(e);if(n!==void 0){var r=n?.getAttribute(`status`);if(r===`loaded`)return Promise.resolve(n);if(r===`loading`)return new Promise(function(e,t){n.addEventListener(`load`,function(){return e(n)}),n.addEventListener(`error`,function(e){return t(e)})})}return new Promise(function(n,r){var i,a=window.document.createElement(`script`);a.type=`text/javascript`,a.src=e,a.async=!0,a.setAttribute(`status`,`loading`);for(var o=0,s=Object.entries(t??{});o<s.length;o++){var c=s[o],l=c[0],u=c[1];a.setAttribute(l,u)}a.onload=function(){a.onerror=a.onload=null,a.setAttribute(`status`,`loaded`),n(a)},a.onerror=function(){a.onerror=a.onload=null,a.setAttribute(`status`,`error`),r(Error(`Failed to load ${e}`))};var d=window.document.querySelector(`script`);d?(i=d.parentElement)==null||i.insertBefore(a,d):window.document.head.appendChild(a)})}function y(e){var t=_(e);return t!==void 0&&t.remove(),Promise.resolve()}var b=e((()=>{}));export{h as a,i as c,a as d,r as f,m as i,c as l,n as m,v as n,g as o,t as p,y as r,p as s,b as t,o as u};
//# sourceMappingURL=88605b43-j0i9gi7r4d8wen8r.js.map
/*
     FILE ARCHIVED ON 21:13:43 Jul 14, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:44 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.516
  captures_list: 0.543
  exclusion.robots: 0.052
  exclusion.robots.policy: 0.04
  esindex: 0.011
  cdx.remote: 12.55
  LoadShardBlock: 57.13 (3)
  PetaboxLoader3.datanode: 148.061 (4)
  load_resource: 305.126
  PetaboxLoader3.resolve: 144.406
*/