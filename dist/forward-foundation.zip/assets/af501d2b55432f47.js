var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{$k as t,HTt as n,VTt as r,eA as i}from"./4813494d-n80qxxy3ebindl2e.js";import{P as a,Ut as o,ft as s,pt as c,tt as l,xt as u}from"./2340486e-i94pm3kv3z1ngaiv.js";import{n as d,t as f}from"./9bfdcf20-gqvrfxohrmxbmtq2.js";import{n as p,t as m}from"./74754c62-gbunip40sr6jebwd.js";import{a as h,n as g,o as _,t as v}from"./fa5bef1d-m3xfosm8bw3n8vtm.js";var y,b,x,S,C,w,T,E=e((()=>{a(),y=u(),p(),i(),n(),_(),g(),d(),b=o(),x={hasRouteMeta:!0,useScrollRestoration:!0},S=({data:e,location:n})=>{let i=e?.routeConfig??v(n.pathname,h);return e?.pageData?[...r(e.pageData,n.pathname),...t(e.routeConfig.routePath,{pageLocalizationConfig:e.pageLocalizationConfig})]:[{title:i?.fallbackTitle??`ChatGPT`}]},C=()=>{"use forget";let e=(0,y.c)(5),{pageData:t,footerData:n,headerNavData:r,locale:i}=l(),a;return e[0]!==n||e[1]!==r||e[2]!==i||e[3]!==t?(a=(0,b.jsx)(m,{page:t,footer:n,headerNav:r,locale:i}),e[0]=n,e[1]=r,e[2]=i,e[3]=t,e[4]=a):a=e[4],a},w=s(C),T=c(f)}));e((()=>{E()}))();export{T as ErrorBoundary,w as default,x as handle,S as meta};
//# sourceMappingURL=contentful-legacy-page-jnxkjnao.js.map
/*
     FILE ARCHIVED ON 16:15:28 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:19 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.549
  captures_list: 0.544
  exclusion.robots: 0.057
  exclusion.robots.policy: 0.046
  esindex: 0.009
  cdx.remote: 5.441
  LoadShardBlock: 134.846 (3)
  PetaboxLoader3.datanode: 164.72 (4)
  PetaboxLoader3.resolve: 96.182 (2)
  load_resource: 141.724
*/