var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";function t(e){try{return decodeURIComponent(e.replace(/\+/g,` `))}catch{return e}}var n=e((()=>{}));export{n,t};
//# sourceMappingURL=e6911992-b0ka1jsskmwpnw22.js.map
/*
     FILE ARCHIVED ON 17:19:00 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:44 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.359
  captures_list: 0.486
  exclusion.robots: 0.05
  exclusion.robots.policy: 0.041
  esindex: 0.011
  cdx.remote: 18.687
  LoadShardBlock: 235.295 (3)
  PetaboxLoader3.resolve: 148.839 (4)
  PetaboxLoader3.datanode: 129.912 (4)
  load_resource: 98.592
*/