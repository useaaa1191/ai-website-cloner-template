var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{i as t,n,r,t as i}from"./4813494d-n80qxxy3ebindl2e.js";e((()=>{i()}))();export{r as default,n as meta,t as shouldRevalidate};
//# sourceMappingURL=root-g05402if.js.map
/*
     FILE ARCHIVED ON 17:18:58 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:19 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 4.322
  captures_list: 0.679
  exclusion.robots: 0.049
  exclusion.robots.policy: 0.038
  esindex: 0.012
  cdx.remote: 23.867
  LoadShardBlock: 53.715 (3)
  PetaboxLoader3.datanode: 83.544 (4)
  load_resource: 122.073
  PetaboxLoader3.resolve: 45.87
*/