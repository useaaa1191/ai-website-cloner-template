var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{J as t,P as n}from"./2340486e-i94pm3kv3z1ngaiv.js";function r(e){return`:lang?${e.routePath.slice(0,-1)}`}var i,a,o,s=e((()=>{i=[{id:`routes/($lang).codex.enterprise`,routePath:`/codex/enterprise/`,cmsSlug:`codex/enterprise`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).codex.georgia-college-students`,routePath:`/codex/georgia-college-students/`,cmsSlug:`codex/georgia-college-students`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).codex.michigan-college-students`,routePath:`/codex/michigan-college-students/`,cmsSlug:`codex/michigan-college-students`,fallbackTitle:`ChatGPT`,urlSlug:`/codex/michigan-college-students/`,headerVariant:`default`},{id:`routes/($lang).codex.new-mexico-college-students`,routePath:`/codex/new-mexico-college-students/`,cmsSlug:`codex/new-mexico-college-students`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).codex.ohio-college-students`,routePath:`/codex/ohio-college-students/`,cmsSlug:`codex/ohio-college-students`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).college-students`,routePath:`/college-students/`,cmsSlug:`college-students`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).images-2-0-giveaway`,routePath:`/images-2-0-giveaway/`,cmsSlug:`images-2-0-giveaway`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).merchants`,routePath:`/merchants/`,cmsSlug:`merchants`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).parent-resources`,routePath:`/parent-resources/`,cmsSlug:`parent-resources`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).import-to-chatgpt`,routePath:`/import-to-chatgpt/`,cmsSlug:`import-to-chatgpt`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).remote`,routePath:`/remote/`,cmsSlug:`remote`,fallbackTitle:`ChatGPT`,headerVariant:`default`},{id:`routes/($lang).work`,routePath:`/work/`,cmsSlug:`work`,fallbackTitle:`ChatGPT`,headerVariant:`default`}],a=[{id:`routes/($lang).overview`,routePath:`/overview/`,cmsSlug:`overview`,fallbackTitle:`ChatGPT Overview`}],o=[{id:`routes/($lang).codex._index`,routePath:`/codex/`,cmsSlug:`codex`,fallbackTitle:`ChatGPT`,variant:`index`}]}));function c(e,n){let i=e.replace(/\.data\/?$/,``);return n.find(e=>t(r(e),i))}var l=e((()=>{s(),n()}));export{a,i,l as n,s as o,o as r,c as t};
//# sourceMappingURL=fa5bef1d-m3xfosm8bw3n8vtm.js.map
/*
     FILE ARCHIVED ON 16:15:07 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:22 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.526
  captures_list: 0.754
  exclusion.robots: 0.081
  exclusion.robots.policy: 0.065
  esindex: 0.013
  cdx.remote: 6.822
  LoadShardBlock: 87.282 (3)
  PetaboxLoader3.datanode: 92.188 (4)
  PetaboxLoader3.resolve: 51.435 (2)
  load_resource: 120.964
*/