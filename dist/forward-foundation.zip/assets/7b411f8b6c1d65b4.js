var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e,s as t}from"./f025431a-nohxu7rfv8lngty8.js";import{ATt as n,jTt as r}from"./4813494d-n80qxxy3ebindl2e.js";import{Ut as i,Wt as a,xt as o}from"./2340486e-i94pm3kv3z1ngaiv.js";import{Gnt as s,Nnt as c,Wnt as l,jnt as u}from"./conversation-small-nj3jro5w24kaci4p.js";import{n as d,t as f}from"./7b12be43-hfsk73ifbsf5y6jq.js";import{n as p,t as m}from"./0cb8459d-ev4herp7ybickx52.js";import{n as h,t as g}from"./bb47c0a1-c8h5zdx0rz95soqk.js";import{a as _,c as v,i as y,n as b,o as x,r as S,s as C,t as w}from"./d9e5e62d-hst4dgqxb59qr2w7.js";function T(e){return p(e,f)}function E(e){return p(e,f)}var D,O,k,A=e((()=>{D=o(),a(),d(),v(),m(),O=i(),k=e=>{"use forget";let t=(0,D.c)(12),{page:n,footer:r,leadSpacing:i}=e,a=i===void 0?`default`:i;if(n.layout.__typename!==`layout`)throw Error(`Page layout is not a layout`);let o,s;if(t[0]!==a||t[1]!==n.layout.components){let e=n?.layout?.components??[],r=a===`tight`&&e.length>1;o=`mt-10 flex flex-col gap-20 overflow-x-clip pb-32 md:px-10`,s=r?(0,O.jsxs)(O.Fragment,{children:[(0,O.jsxs)(`div`,{className:`flex flex-col gap-8`,children:[p(e[0],f),p(e[1],f)]}),e.slice(2).map(T)]}):e.map(E),t[0]=a,t[1]=n.layout.components,t[2]=o,t[3]=s}else o=t[2],s=t[3];let c;t[4]!==o||t[5]!==s?(c=(0,O.jsx)(`div`,{className:o,children:s}),t[4]=o,t[5]=s,t[6]=c):c=t[6];let l;t[7]===r?l=t[8]:(l=r&&(0,O.jsx)(C,{footer:r}),t[7]=r,t[8]=l);let u;return t[9]!==c||t[10]!==l?(u=(0,O.jsxs)(`div`,{children:[c,l]}),t[9]=c,t[10]=l,t[11]=u):u=t[11],u}}));function j(e){return!e}var M,N,P,F,I=e((()=>{M=o(),c(),s(),r(),N=t(a()),h(),y(),x(),b(),A(),P=i(),F=e=>{"use forget";let t=(0,M.c)(22),[r,i]=(0,N.useState)(!1),a;t[0]===Symbol.for(`react.memo_cache_sentinel`)?(a=()=>{i(j)},t[0]=a):a=t[0];let o=a,s=!!e.headerNav?.secondaryCta,c;t[1]===r?c=t[2]:(c={isNavigationMobileOpen:r,toggleNavigationMobile:o},t[1]=r,t[2]=c);let d,f;t[3]!==s||t[4]!==e.headerNav?(d=(0,P.jsx)(S,{navData:e.headerNav,isHeaderTooCrowdedForLg:s}),f=(0,P.jsx)(w,{data:e.headerNav,isHeaderTooCrowdedForLg:s}),t[3]=s,t[4]=e.headerNav,t[5]=d,t[6]=f):(d=t[5],f=t[6]);let p;t[7]!==e.footer||t[8]!==e.page?(p=(0,P.jsx)(`div`,{className:`pt-mkt-header-height`,children:(0,P.jsx)(k,{page:e.page,footer:e.footer,leadSpacing:`default`})}),t[7]=e.footer,t[8]=e.page,t[9]=p):p=t[9];let m;t[10]===Symbol.for(`react.memo_cache_sentinel`)?(m=(0,P.jsxs)(n,{children:[(0,P.jsx)(l,{}),(0,P.jsx)(u,{fixed:!0})]}),t[10]=m):m=t[10];let h;t[11]!==d||t[12]!==f||t[13]!==p?(h=(0,P.jsxs)(`div`,{className:`bg-token-bg-primary text-token-text-primary font-oai`,children:[d,f,p,m]}),t[11]=d,t[12]=f,t[13]=p,t[14]=h):h=t[14];let v;t[15]!==e.locale||t[16]!==e.page.slug||t[17]!==h?(v=(0,P.jsx)(g,{effectiveLocale:e.locale,slug:e.page.slug,children:h}),t[15]=e.locale,t[16]=e.page.slug,t[17]=h,t[18]=v):v=t[18];let y;return t[19]!==c||t[20]!==v?(y=(0,P.jsx)(_.Provider,{value:c,children:v}),t[19]=c,t[20]=v,t[21]=y):y=t[21],y}}));export{I as n,F as t};
//# sourceMappingURL=74754c62-gbunip40sr6jebwd.js.map
/*
     FILE ARCHIVED ON 11:54:25 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:19 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 0.506
  captures_list: 0.768
  exclusion.robots: 0.085
  exclusion.robots.policy: 0.069
  esindex: 0.015
  cdx.remote: 19.524
  LoadShardBlock: 62.226 (3)
  PetaboxLoader3.datanode: 66.816 (4)
  load_resource: 33.124
*/