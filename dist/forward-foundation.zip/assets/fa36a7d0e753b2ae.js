var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e,s as t}from"./f025431a-nohxu7rfv8lngty8.js";import{Qk as n,eA as r}from"./4813494d-n80qxxy3ebindl2e.js";import{Ut as i,Wt as a,xt as o}from"./2340486e-i94pm3kv3z1ngaiv.js";function s(e){"use forget";let t=(0,l.c)(8),{children:n,slug:r,effectiveLocale:i,layout:a}=e,[o,s]=(0,u.useState)(0),c;t[0]!==i||t[1]!==a||t[2]!==r||t[3]!==o?(c={effectiveLocale:i,layout:a,slug:r,theme:o,setTheme:s},t[0]=i,t[1]=a,t[2]=r,t[3]=o,t[4]=c):c=t[4];let p;return t[5]!==n||t[6]!==c?(p=(0,d.jsx)(f.Provider,{value:c,children:n}),t[5]=n,t[6]=c,t[7]=p):p=t[7],p}function c(){"use forget";let e=(0,u.useContext)(f);if(e==null)throw Error(`useContentfulPageContext hook must be used within ContentfulPageProvider`);return e}var l,u,d,f,p=e((()=>{l=o(),r(),u=t(a()),d=i(),f=(0,u.createContext)({effectiveLocale:n,layout:void 0,slug:`/`,theme:0,setTheme:()=>{}})}));export{p as n,c as r,s as t};
//# sourceMappingURL=bb47c0a1-c8h5zdx0rz95soqk.js.map
/*
     FILE ARCHIVED ON 13:31:51 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:22 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 2.463
  captures_list: 0.742
  exclusion.robots: 0.102
  exclusion.robots.policy: 0.089
  esindex: 0.012
  cdx.remote: 18.347
  LoadShardBlock: 123.354 (3)
  PetaboxLoader3.datanode: 97.99 (4)
  load_resource: 97.268
  PetaboxLoader3.resolve: 48.199
*/