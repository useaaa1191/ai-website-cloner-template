var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}var window = _____WB$wombat$assign$function_____("window");
var self = _____WB$wombat$assign$function_____("self");
var document = _____WB$wombat$assign$function_____("document");
var location = _____WB$wombat$assign$function_____("location");
var top = _____WB$wombat$assign$function_____("top");
var parent = _____WB$wombat$assign$function_____("parent");
var frames = _____WB$wombat$assign$function_____("frames");
var opener = _____WB$wombat$assign$function_____("opener");
import{n as e,s as t}from"./f025431a-nohxu7rfv8lngty8.js";import{$_t as n,Q_t as r,Szt as i,TT as a,gT as o,xzt as s}from"./4813494d-n80qxxy3ebindl2e.js";import{Ut as c,Wt as l,xt as u}from"./2340486e-i94pm3kv3z1ngaiv.js";function d(e){return clearTimeout(e)}var f,p,m,h,g=e((()=>{f=u(),i(),p=t(l()),o(),r(),m=c(),h=e=>{"use forget";let t=(0,f.c)(27),{direction:r,items:i,carouselSpeed:o,itemWrapperClassName:c,threshold:l,contentfulDebugAttributes:u}=e,h=r===void 0?`Left`:r,g=o===void 0?36:o,_=l===void 0?1:l,[v,y]=(0,p.useState)(3),b=(0,p.useRef)(null),x=(0,p.useRef)(null),[S,C]=(0,p.useState)(!0),[w,T]=(0,p.useState)(g*(i.length/5)),E;t[0]===Symbol.for(`react.memo_cache_sentinel`)?(E=function(){x?.current&&(C(!1),setTimeout(()=>{x?.current&&C(!0)},10))},t[0]=E):E=t[0];let D=E,O;t[1]===Symbol.for(`react.memo_cache_sentinel`)?(O=[],t[1]=O):O=t[1];let k=(0,p.useRef)(O),A;t[2]===Symbol.for(`react.memo_cache_sentinel`)?(A={initializeWithValue:!1},t[2]=A):A=t[2];let{width:j}=a(A),M=j===void 0?0:j,N,P;t[3]===_?(N=t[4],P=t[5]):(N=()=>{let e=new Map,t=new IntersectionObserver(t=>{t.forEach(t=>{if(!(t.target instanceof HTMLDivElement))return;let n=t.target;clearTimeout(e.get(n)),e.delete(n),e.set(n,setTimeout(()=>{t.isIntersecting?n.classList.remove(`opacity-20`):n.classList.add(`opacity-20`)},100))})},{root:null,threshold:_});return k.current.forEach(e=>{e&&t.observe(e)}),()=>{t.disconnect(),e.forEach(d)}},P=[_],t[3]=_,t[4]=N,t[5]=P),(0,p.useEffect)(N,P);let F;t[6]!==g||t[7]!==i.length||t[8]!==v?(F=()=>{if(!x?.current||!b?.current)return;let{width:e}=x.current.getBoundingClientRect(),{width:t}=b.current.getBoundingClientRect(),n=t-e,r=e/x.current.children.length;T(g*(i.length/5)),n&&v+Math.ceil(n/r)+1>v&&(y(v+Math.ceil(n/r)+1),D())},t[6]=g,t[7]=i.length,t[8]=v,t[9]=F):F=t[9];let I=F,L;t[10]===I?L=t[11]:(L=()=>{I()},t[10]=I,t[11]=L);let R;t[12]!==I||t[13]!==M?(R=[I,M],t[12]=I,t[13]=M,t[14]=R):R=t[14],n(L,R);let z;t[15]===v?z=t[16]:(z=[...Array(v)],t[15]=v,t[16]=z);let B;t[17]!==S||t[18]!==h||t[19]!==c||t[20]!==i||t[21]!==w||t[22]!==z?(B=(0,m.jsx)(`div`,{className:`group/carousel flex w-[fit-content] justify-center`,ref:x,children:z.map((e,t)=>(0,m.jsx)(`div`,{className:s(`flex w-[max-content] animate-none transition-opacity duration-800 [animation-play-state:paused]`,{"group-hover/carousel:[animation-play-state:paused] motion-safe:animate-[mkt-slide-anim_linear_infinite] motion-safe:[animation-play-state:running]":S}),style:{animationDuration:`${w}s`,animationDirection:h===`Right`?`reverse`:`normal`},children:i.map((e,t)=>(0,m.jsx)(`div`,{className:s(`mx-1 flex items-start transition-opacity duration-800`,c),ref:e=>{e&&!k.current.includes(e)&&k.current.push(e)},children:e},t))},t))}),t[17]=S,t[18]=h,t[19]=c,t[20]=i,t[21]=w,t[22]=z,t[23]=B):B=t[23];let V;return t[24]!==u||t[25]!==B?(V=(0,m.jsx)(`div`,{...u,className:`looper @container w-full`,ref:b,children:B}),t[24]=u,t[25]=B,t[26]=V):V=t[26],V}}));export{g as n,h as t};
//# sourceMappingURL=8a4ddaf7-ddcsw4ukvlrsvqyo.js.map
/*
     FILE ARCHIVED ON 11:54:27 Jul 15, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:21 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  capture_cache.get: 1114.337
  captures_list: 0.575
  exclusion.robots: 0.052
  exclusion.robots.policy: 0.042
  esindex: 0.009
  cdx.remote: 15.215
  LoadShardBlock: 83.948 (3)
  PetaboxLoader3.datanode: 79.432 (4)
  load_resource: 126.497
  PetaboxLoader3.resolve: 90.519
*/