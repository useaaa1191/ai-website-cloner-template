var _____WB$wombat$assign$function_____=function(name){return (globalThis._wb_wombat && globalThis._wb_wombat.local_init && globalThis._wb_wombat.local_init(name))||globalThis[name];};if(!globalThis.__WB_pmw){globalThis.__WB_pmw=function(obj){this.__WB_source=obj;return this;}}{
let window = _____WB$wombat$assign$function_____("window");
let self = _____WB$wombat$assign$function_____("self");
let document = _____WB$wombat$assign$function_____("document");
let location = _____WB$wombat$assign$function_____("location");
let top = _____WB$wombat$assign$function_____("top");
let parent = _____WB$wombat$assign$function_____("parent");
let frames = _____WB$wombat$assign$function_____("frames");
let opener = _____WB$wombat$assign$function_____("opener");
import{n as e}from"./f025431a-nohxu7rfv8lngty8.js";import{$dt as t,Qdt as n,Zdt as r,eft as i,ift as a,rft as o}from"./4813494d-n80qxxy3ebindl2e.js";import{t as s,u as c}from"./5ab42519-f80ft9afniv4c4g4.js";import{f as l,p as u}from"./88605b43-j0i9gi7r4d8wen8r.js";import{c as d,s as f}from"./fd7f274b-gll9bzwd8s2qpec2.js";function p(){return u()?window.navigator.onLine:!0}function m(){return!p()}var h=e((()=>{l()})),g=e((()=>{s()}));function _(e){var t=C.getItem(e);return(t?JSON.parse(t):[]).map(function(e){return new f(e.event,e.id)})}function v(e,t){var n=_(e),i=o(o([],t,!0),n,!0).reduce(function(e,t){var n;return r(r({},e),(n={},n[t.id]=t,n))},{});C.setItem(e,JSON.stringify(Object.values(i)))}function y(e){var t=C.getItem(e);return t?JSON.parse(t):{}}function b(e,t){var n=y(e);C.setItem(e,JSON.stringify(r(r({},n),t)))}function x(e){C.removeItem(e)}function S(e,t,n){n===void 0&&(n=0);var r=50,i=`persisted-queue:v1:${e}:lock`,a=function(e){return new Date().getTime()>e},o=C.getItem(i),s=o?JSON.parse(o):null,c=s===null||a(s);if(c){C.setItem(i,JSON.stringify(w()+r)),t(),C.removeItem(i);return}!c&&n<3?setTimeout(function(){S(e,t,n+1)},r):console.error(`Unable to retrieve lock`)}var C,w,T,E=e((()=>{a(),g(),d(),l(),C={getItem:function(){},setItem:function(){},removeItem:function(){}};try{C=u()&&window.localStorage?window.localStorage:C}catch(e){console.warn(`Unable to access localStorage`,e)}w=function(){return new Date().getTime()},T=function(e){t(n,e);function n(t,n){var i=e.call(this,t,[])||this,a=`persisted-queue:v1:${n}:items`,s=`persisted-queue:v1:${n}:seen`,c=[],l={};return S(n,function(){try{c=_(a),l=y(s),x(a),x(s),i.queue=o(o([],c,!0),i.queue,!0),i.seen=r(r({},l),i.seen)}catch(e){console.error(e)}}),window.addEventListener(`pagehide`,function(){if(i.todo>0){var e=o(o([],i.queue,!0),i.future,!0);try{S(n,function(){v(a,e),b(s,i.seen)})}catch(e){console.error(e)}}}),i}return n}(c)})),D,O=e((()=>{a(),D=function(e,t){return n(void 0,void 0,void 0,function(){var r;return i(this,function(a){return r=function(a){return n(void 0,void 0,void 0,function(){var n;return i(this,function(i){switch(i.label){case 0:return e(a)?(n=r,[4,t()]):[3,2];case 1:return[2,n.apply(void 0,[i.sent()])];case 2:return[2]}})})},[2,r(void 0)]})})}}));function k(e,t){var n=Object.entries(t.integrations??{}).reduce(function(e,t){var n,i,a=t[0],o=t[1];return typeof o==`object`?r(r({},e),(n={},n[a]=o,n)):r(r({},e),(i={},i[a]={},i))},{});return Object.entries(e.integrations).reduce(function(e,t){var i,a=t[0],o=t[1];return r(r({},e),(i={},i[a]=r(r({},o),n[a]),i))},{})}var A=e((()=>{a()}));function j(e,t){var n=t.methodName,r=t.integrationName,i=t.type,a=t.didError,o=a===void 0?!1:a;e.stats.increment(`analytics_js.integration.invoke${o?`.error`:``}`,1,[`method:${n}`,`integration_name:${r}`,`type:${i}`])}var M=e((()=>{}));export{O as a,E as c,m as d,p as f,k as i,g as l,j as n,D as o,A as r,T as s,M as t,h as u};
//# sourceMappingURL=be58453f-gfohycpqeoivpsi6.js.map
}

/*
     FILE ARCHIVED ON 21:13:43 Jul 14, 2026 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:04:46 Jul 22, 2026.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.744
  exclusion.robots: 0.091
  exclusion.robots.policy: 0.071
  esindex: 0.015
  cdx.remote: 6.942
  LoadShardBlock: 67.089 (3)
  PetaboxLoader3.datanode: 1161.895 (4)
  load_resource: 1148.062
  PetaboxLoader3.resolve: 32.143
*/