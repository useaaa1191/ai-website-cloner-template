Forward Foundation native static site
=====================================

This folder is the production static export of the Forward Foundation website.
It can be hosted on any static host (Vercel, Netlify, Cloudflare Pages, S3,
GitHub Pages, or a normal web server).

Local preview
-------------

  python3 -m http.server 8765
  # then open http://127.0.0.1:8765

Source
------

The editable Next.js source is in the repository under src/. Run:

  npm install
  npm run build

The build is configured with `output: "export"` and writes this out/ folder.

Verification
------------

- Next.js 16 production build: passed
- TypeScript strict check: passed
- ESLint: passed with pre-existing script warnings only
- Playwright desktop 1440x900: no errors, failed requests, or overflow
- Playwright mobile 390x844: no errors, failed requests, or overflow

The package intentionally excludes the unused OpenAI-clone image/video library.
All visible illustrations and interface mockups are original Forward Foundation
components rendered in HTML, CSS, and SVG.
