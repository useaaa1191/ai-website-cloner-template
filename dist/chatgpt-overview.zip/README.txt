ChatGPT Overview - Offline Snapshot
====================================

Static clone of https://chatgpt.com/overview/
Source snapshot: Wayback Machine capture from 2026-07-15
Captured with Playwright + Chromium, all remote URLs rewritten to local paths.

Files
-----
index.html      Entry point.
assets/         All CSS, JS, images, fonts, and JSON captured from the live page.
serve.sh        Convenience script that starts a local HTTP server on port 8765.

How to view
-----------
Recommended (JS + fonts work): run a local server and open the URL.

    ./serve.sh
    # then open http://127.0.0.1:8765 in your browser

    # or, one-liner:
    python3 -m http.server 8765 --bind 127.0.0.1

    # or with node:
    npx --yes http-server -p 8765 .

Also works but limited: open index.html directly in a browser (file://).
Some JS and font files will fail to load because browsers block ES modules and
CORS-restricted assets over the file:// scheme. Layout and images still render.

Notes
-----
- All third-party trackers/analytics were captured too; they may make outbound
  requests that fail silently. This does not affect rendering.
- The page's original login/signup flow is server-driven and will not work from
  this static mirror; the buttons are still visible and clickable.
